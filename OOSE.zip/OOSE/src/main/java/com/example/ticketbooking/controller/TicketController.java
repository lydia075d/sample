package com.example.ticketbooking.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

@Controller
public class TicketController {

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        if ("user".equals(username) && "pass".equals(password)) {
            return "booking";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "login";
        }
    }

    @PostMapping("/book")
    public String book(@RequestParam String name,
                       @RequestParam String event,
                       @RequestParam String seat,
                       Model model) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter("bookings.txt", true))) {
            writer.println("Name: " + name + ", Event: " + event + ", Seat: " + seat);
        }
        model.addAttribute("message", "Booking successful!");
        return "booking";
    }
}
